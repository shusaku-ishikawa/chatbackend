from django.apps import AppConfig


class FtpappConfig(AppConfig):
    name = 'ftpapp'
