from django.conf.urls import url
from django.urls import path, re_path
from . import views
from django.contrib.auth.views import LogoutView

app_name = 'ftpapp'

urlpatterns = [
    re_path(r'(?P<path>^.*$)', views.MainView.as_view()),
]