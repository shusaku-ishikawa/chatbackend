from django import template
register = template.Library()

@register.filter
def parentfolder(value, arg):
    value = value.split('/')
    if len(value) < 2:
        return "#"
    else:
        return '/'.join(value[:len(value) - 2])
@register.filter
def remotedirectory(value, arg):
    return value.replace('/app', '')