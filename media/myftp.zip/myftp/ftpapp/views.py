from django.shortcuts import render
from django.views.generic import TemplateView
from ftplib import FTP_TLS, error_perm
from django.contrib import messages
import os, ftplib

ftp_host_name = 'ftp.yoshifuku1411.icurus.jp'
ftp_user = 'icurus.jp-yoshifuku1411'
ftp_password = '6iuLz5R2fB3d'
FTP_TLS.encoding = "utf-8"

def ftp_connect(host, user, passwd):
    try:
        ftp = FTP_TLS(host = host, user = user, passwd = passwd)
    except Exception as e:
        print(e)
        return None
    else:
        return ftp
def ftp_quit(ftp_object):
    ftp_object.quit()

# return generater
def get_file_list(ftp_object, path):
    ftp_object.cwd(path)
    current = ftp_object.pwd()
    print(current)
    files = [f for f in ftp_object.mlsd()]
    return files
    
def put_file(ftp_object, path, file_name, file_data):
    ftp_object.cwd(path)
    ftp_object.storbinary('STOR {}'.format(file_name), file_data)  
def delete_file(ftp_object, path):
    #ftp_object.cwd(path)
    ftp_object.delete(path)

def delete_folder(ftp, path):
    wd = ftp.pwd()
    try:
        names = ftp.nlst(path)
    except ftplib.all_errors as e:
        # some FTP servers complain when you try and list non-existent paths
        raise e

    for name in names:
        if os.path.split(name)[1] in ('.', '..'): continue

        try:
            ftp.cwd(name)  # if we can cwd to it, it's a folder
            ftp.cwd(wd)  # don't try a nuke a folder we're in
            delete_folder(ftp, name)
        except ftplib.all_errors:
            ftp.delete(name)

    try:
        ftp.rmd(path)
    except ftplib.all_errors as e:
        messages.erorr
def create_folder(ftp_object, base_path, folder_name):
    ftp_object.cwd(base_path)
    ftp_object.pwd()
    existing_folders = [fol for (fol, info) in ftp_object.mlsd() if info.get('type') == 'dir']
    if not folder_name in existing_folders:
        ftp_object.mkd(folder_name)

def handle_create(request, ftp, remote_directory):
    upload_type = request.POST.get('flag')
        
    if upload_type == 'file':
        files = request.FILES.getlist('upload-files[]')
        for file in files:
            try:
                put_file(ftp, remote_directory, file.name, file.file)
            except Exception as e:
                print(e)
                messages.error(request, str(e))
            else:
                messages.success(request, 'Upload succeeded {}!!'.format(file.name))
    elif upload_type == 'folder':
        files = request.FILES.getlist('upload-folder[]')
        pathlist = request.POST.getlist('upload-folder-path')
        for i in range(len(files)):
            file_data = files[i]
            path = pathlist[i]
            path_array = path.split('/')
            file_name = path_array[len(path_array) - 1]
            fols = path_array[:len(path_array) - 1]
            base_fol = remote_directory
            folder_create_succeed = True
            for fol in fols:
                # create folder
                try:
                    create_folder(ftp, base_fol, fol)
                except Exception as e:
                    messages.error(request, 'create folder failed {}'.format(base_fol + '/' + fol))
                    folder_create_succeed = False
                    break
                else:
                    base_fol += (fol if base_fol == '' else ('/' + fol))
                print(base_fol)
            if folder_create_succeed:
                try:   
                    put_file(ftp, base_fol, file_name, file_data)
                except Exception as e:
                    messages.error('file upload failed {}'.format(path))
                else:
                    messages.success(request, '{} uploaded!!'.format(path))
def handle_delete(request, ftp, remote_directory):
    delete_type = request.POST.get('delete-type')
    target = request.POST.get('target')
    path = '{}/{}'.format(remote_directory, target)
    delete_func = delete_file if delete_type == 'file' else delete_folder
    try:
        delete_func(ftp, path)
    except Exception as e:
        print(e)
        messages.error(request, str(e))
    else:
        messages.success(request, 'Delete succeeded {}!!'.format(target))

class MainView(TemplateView):
    template_name = 'main_view.html'
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        remote_dir = kwargs['path']
    
        cwd = '/app/{}'.format(remote_dir)
        context['path'] = cwd if remote_dir == '' else '{}/'.format(cwd)
        
        ftp = ftp_connect(ftp_host_name, ftp_user, ftp_password)
        if not ftp:
            print('login failed')
            messages.error(self.request, 'login failed')
        else:
            try:
                files = get_file_list(ftp, remote_dir)
            except error_perm as e:
                # no path found
                messages.error(self.request, str(e))
            else:
                context['files'] = files
                return context
            finally:
                ftp_quit(ftp)
    def post(self, request, **kwargs):
        cwd = '/{}'.format(kwargs['path'])
        ftp = ftp_connect(ftp_host_name, ftp_user, ftp_password)
        if not ftp:
            print('login failed')
            messages.error(self.request, 'login failed')
        else:
            action = request.POST.get('action')
            print(action)
            if action == 'add':
                handle_create(request, ftp, cwd)
            elif action == 'delete':
                handle_delete(request, ftp, cwd)
        ftp_quit(ftp)
        return super().get(self.request, **kwargs)